# -*- coding: utf-8 -*-
"""
_version.py
===========

Version info for ``ResearchPlot`` package.
"""

__version__ = "0.0.1"
